
#ifndef equivNode_
#define equivNode_

struct equivNode 
{
   int equivClass,  // element class identifier
       size,        // number of elements in class
       next;        // pointer to next element in class
};

#endif
